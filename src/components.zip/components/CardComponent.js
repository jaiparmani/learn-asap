import React from "react";
import {
  MDBCard,
  MDBCardTitle,
  MDBBtn,
  MDBCardGroup,
  MDBCardImage,
  MDBCardText,
  MDBCardBody,
} from "mdbreact";
import img1 from "../assets/card1.jpeg";
import img2 from "../assets/card2.jpeg";
import img3 from "../assets/card3.jpeg";
import img4 from "../assets/card4.jpeg";
import img5 from "../assets/card5.jpeg";
import img6 from "../assets/card6.jpeg";

const CardExample = () => {
  return (
    <>
      <MDBCardGroup style={{ height: "520px" }}>
        <MDBCard style={{ height: "500px", margin: "22px" }}>
          <MDBCardImage
            style={{
              height: "400px",
              width: "100%",
              padding: "0px",
              margin: "auto",
            }}
            src={img2}
            alt="MDBCard image cap"
            top
            hover
            overlay="white-slight"
          />
          <MDBCardBody style={{ height: "130px" }}>
            <MDBCardTitle style={{ display: "inline-block" }} tag="h5">
              Subject: KNN
            </MDBCardTitle>
            <MDBCardText
              style={{
                display: "inline-block",
                float: "right",
                marginLeft: "10px",
                border: "1px solid black",
                // backgroundColor: "black",
                // borderRadius: "10px",
                padding: "5px",
                color: "black",
              }}>
              Semester 8, IT
            </MDBCardText>
            <MDBBtn
              style={{
                margin: "auto",
                width: "100%",
                display: "block",
              }}
              color="dark"
              size="md">
              Watch Video
            </MDBBtn>
          </MDBCardBody>
        </MDBCard>

        <MDBCard style={{ height: "500px", margin: "22px" }}>
          <MDBCardImage
            style={{
              height: "400px",
              width: "100%",
              padding: "0px",
              margin: "auto",
            }}
            src={img1}
            alt="MDBCard image cap"
            top
            hover
            overlay="white-slight"
          />
          <MDBCardBody style={{ height: "130px" }}>
            <MDBCardTitle style={{ display: "inline-block" }} tag="h5">
              Subject: DMBS
            </MDBCardTitle>
            <MDBCardText
              style={{
                display: "inline-block",
                float: "right",
                marginLeft: "10px",
                border: "1px solid black",
                padding: "5px",
                color: "black",
              }}>
              Semester 8, IT
            </MDBCardText>
            <MDBBtn
              style={{
                margin: "auto",
                width: "100%",
                display: "block",
              }}
              color="dark"
              size="md">
              Watch Video
            </MDBBtn>
          </MDBCardBody>
        </MDBCard>

        <MDBCard style={{ height: "500px", margin: "22px" }}>
          <MDBCardImage
            style={{
              height: "400px",
              width: "100%",
              padding: "0px",
              margin: "auto",
            }}
            src={img3}
            alt="MDBCard image cap"
            top
            hover
            overlay="white-slight"
          />
          <MDBCardBody style={{ height: "130px" }}>
            <MDBCardTitle style={{ display: "inline-block" }} tag="h5">
              Panel title
            </MDBCardTitle>
            <MDBCardText
              style={{
                display: "inline-block",
                float: "right",
                marginLeft: "10px",
                border: "1px solid black",
                padding: "5px",
                color: "black",
              }}>
              Semester 8, IT
            </MDBCardText>
            <MDBBtn
              style={{
                margin: "auto",
                width: "100%",
                display: "block",
              }}
              color="dark"
              size="md">
              Watch Video
            </MDBBtn>
          </MDBCardBody>
        </MDBCard>
      </MDBCardGroup>

      <MDBCardGroup style={{ height: "520px" }}>
        <MDBCard style={{ height: "500px", margin: "22px" }}>
          <MDBCardImage
            style={{
              height: "400px",
              width: "100%",
              padding: "0px",
              margin: "auto",
            }}
            src={img4}
            alt="MDBCard image cap"
            top
            hover
            overlay="white-slight"
          />
          <MDBCardBody>
            <MDBCardTitle style={{ display: "inline-block" }} tag="h5">
              Panel title
            </MDBCardTitle>
            <MDBCardText
              style={{
                display: "inline-block",
                float: "right",
                marginLeft: "10px",
                border: "1px solid black",
                padding: "5px",
                color: "black",
              }}>
              Semester 8, IT
            </MDBCardText>
            <MDBBtn
              style={{
                margin: "auto",
                width: "100%",
                display: "block",
              }}
              color="dark"
              size="md">
              Watch Video
            </MDBBtn>
          </MDBCardBody>
        </MDBCard>

        <MDBCard style={{ height: "500px", margin: "22px" }}>
          <MDBCardImage
            style={{
              height: "400px",
              width: "100%",
              padding: "0px",
              margin: "auto",
            }}
            src={img5}
            alt="MDBCard image cap"
            top
            hover
            overlay="white-slight"
          />
          <MDBCardBody>
            <MDBCardTitle style={{ display: "inline-block" }} tag="h5">
              Panel title
            </MDBCardTitle>
            <MDBCardText
              style={{
                display: "inline-block",
                float: "right",
                marginLeft: "10px",
                border: "1px solid black",
                padding: "5px",
                color: "black",
              }}>
              Semester 8, IT
            </MDBCardText>
            <MDBBtn
              style={{
                margin: "auto",
                width: "100%",
                display: "block",
              }}
              color="dark"
              size="md">
              Watch Video
            </MDBBtn>
          </MDBCardBody>
        </MDBCard>

        <MDBCard style={{ height: "500px", margin: "22px" }}>
          <MDBCardImage
            style={{
              height: "400px",
              width: "100%",
              padding: "0px",
              margin: "auto",
            }}
            src={img6}
            alt="MDBCard image cap"
            top
            hover
            overlay="white-slight"
          />
          <MDBCardBody>
            <MDBCardTitle style={{ display: "inline-block" }} tag="h5">
              Panel title
            </MDBCardTitle>
            <MDBCardText
              style={{
                display: "inline-block",
                float: "right",
                marginLeft: "10px",
                border: "1px solid black",
                padding: "0px",
                color: "black",
              }}>
              Semester 8, IT
            </MDBCardText>
            <MDBBtn
              style={{
                margin: "auto",
                width: "100%",
                display: "block",
              }}
              color="dark"
              size="md">
              Watch Video
            </MDBBtn>
          </MDBCardBody>
        </MDBCard>
      </MDBCardGroup>
    </>
  );
};

export default CardExample;
